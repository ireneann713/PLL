#!/bin/sh
unset TCL_LIBRARY;  cd /home/irene/synopsys_custom/VCOtest.icv.drc; exec-oa22.60.021.icv icv -f gdsii -i /home/irene/synopsys_custom/VCOtest.icv.drc/VCOtest.custom_compiler.gds -c VCOtest -oa_dm6 -vue /home/skandha/Tools_SNPS/Downloads_temp/SAED32nm_PDK_09302020/icv/drc/saed32nm_1p9m_drc_rules.rs > /home/irene/synopsys_custom/VCOtest.icv.drc/stdout.drc.log 2>&1
