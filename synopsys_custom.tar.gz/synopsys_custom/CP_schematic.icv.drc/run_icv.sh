#!/bin/sh
unset TCL_LIBRARY;  cd /home/irene/synopsys_custom/CP_schematic.icv.drc; exec-oa22.60.021.icv icv -f gdsii -i /home/irene/synopsys_custom/CP_schematic.icv.drc/CP_schematic.custom_compiler.gds -c CP_schematic -oa_dm6 -vue /home/skandha/Tools_SNPS/Downloads_temp/SAED32nm_PDK_09302020/icv/drc/saed32nm_1p9m_drc_rules.rs > /home/irene/synopsys_custom/CP_schematic.icv.drc/stdout.drc.log 2>&1
